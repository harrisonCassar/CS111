#NAME: Harrison Cassar
#EMAIL: Harrison.Cassar@gmail.com
#ID: 505114980
#!/bin/bash
python lab3b.py $@